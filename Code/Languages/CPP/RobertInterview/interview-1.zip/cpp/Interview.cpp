/**
 * @file Interview.cpp
 * @author FridaySky
 * @date October 2019
 * 
 * @brief C++ interview prep
 */

/***
    1. Dynamic memory
    2. Dynamic array allocation
    3. Polymorphism (virtual keyword)
    4. Templates
***/

#include <array>
#include <iostream>

/* Function prototypes */
void printArray(int a[][2], size_t size);

template<std::size_t SIZE>
void modifyContainerArrayByReference(std::array<int, SIZE> *a);

template<std::size_t SIZE>
void modifyContainerArrayByValue(std::array<int, SIZE> a);

template<std::size_t SIZE>
void printContainerArray(std::array<int, SIZE> a);


/*** ================================================== C ARRAYS ================================================== ***/

/**
 * Print a language built-in array inherited from C
 * 
 * Notice that the first brackets [] are left empty, while the following ones specify sizes for their respective dimensions.
 * This is necessary in order for the compiler to be able to determine the depth of each additional dimension
 * 
 * @param[in] a    - Two-dimensional integer array with 'size' rows and 2 columns
 * @param[in] size - Unsigned integer indicating number of rows in array 'a'
 */
void printArray(int a [][2], size_t size) {

    std::cout << "Language built-in array" << std::endl;

    for (size_t i = 0; i < size; ++i) {

        for (size_t j = 0; j < 2; j++) {

            std::cout << a[i][j] << ' ';
        }

        std::cout << std::endl;
    }

    std::cout << std::endl;
}


/*** ================================================== C++ ARRAYS ================================================== ***/

/**
 * Modify the actual std::array 'a'
 * 
 * @tparam SIZE  - Unsigned integer indicating size of array 'a'
 * @param[out] a - Pointer to a one-dimensional integer std::array of size 'SIZE'
 */
template<std::size_t SIZE>
void modifyContainerArrayByReference(std::array<int, SIZE> *a) {

    std::cout << "modifyContainerArrayByReference()";

    for (size_t i = 0; i < a->size(); ++i) {

        ++(*a)[i];
    }

    std::cout << std::endl;

    printContainerArray(*a);
}

/**
 * Modify a copy of the std::array 'a'
 * 
 * @tparam SIZE - Unsigned integer indicating size of array 'a'
 * @param[in] a - PointerOne-dimensional integer std::array of size 'SIZE'
 */
template<std::size_t SIZE>
void modifyContainerArrayByValue(std::array<int, SIZE> a) {

    std::cout << "modifyContainerArrayByValue()";

    for (size_t i = 0; i < a.size(); ++i) {

        ++a[i];
    }

    std::cout << std::endl;

    printContainerArray(a);
}

/**
 * Print a std::array
 * 
 * @tparam SIZE - Unsigned integer indicating size of array 'a'
 * @param[in] a - One-dimensional integer std::array of size 'SIZE'
 */
template<std::size_t SIZE>
void printContainerArray(std::array<int, SIZE> a) {
    
    for (auto e : a) {

        std::cout << e << std::endl;
    }

    std::cout << std::endl;
}


/*** ================================================== MAIN ================================================== ***/

/**
 * Function to be called at program startup
 * 
 * @param argc - Number of arguments, including the program name
 * @param argv - Array of character pointers listing all arguments
 * @return 0 to indicate successful exit status
 */
int main(int argc, char **argv) {

    // /* ---------------------------------------------------------------------------------------------------- */
    // /* Language built-in array */
    // int a [2][2] {
    //     1, 2, 3, 4
    // };

    // printArray(a, 2);

    /* ---------------------------------------------------------------------------------------------------- */
    /* Container library array (aka std::array) */
    std::array<int, 3> b {10, 20, 30};

    // /* ************************************************** */
    // /* Show that actual contents were not changed because we passed in 'b' by value */
    // modifyContainerArrayByValue(b);

    // std::cout << "Printing std::array from main() after passing-by-value" << std::endl;
    // printContainerArray(b);

    /* ************************************************** */
    /* Show that actual contents were changed because we passed in 'b' by reference */
    modifyContainerArrayByReference(&b);
    
    std::cout << "Printing std::array from main() after passing-by-reference" << std::endl;
    printContainerArray(b);

    /* Move on */


    return 0;
}

